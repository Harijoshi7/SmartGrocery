import React from "react"
export default function NotFound(){
  return <div className="card"><h2>404</h2><p>Page not found.</p></div>
}
