const db = require('../config/database');

const authenticate = (req, res, next) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  next();
};

const authorize = (...allowedRoles) => {
  return async (req, res, next) => {
    try {
      if (!req.session || !req.session.userId) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const [users] = await db.query(
        `SELECT u.UserID, u.Username, r.RoleName 
         FROM User u 
         JOIN Role r ON u.RoleID = r.RoleID 
         WHERE u.UserID = ?`,
        [req.session.userId]
      );

      if (users.length === 0) {
        return res.status(401).json({ error: 'User not found' });
      }

      const user = users[0];
      req.user = user;

      if (!allowedRoles.includes(user.RoleName)) {
        return res.status(403).json({ error: 'Insufficient permissions' });
      }

      next();
    } catch (error) {
      console.error('Authorization error:', error);
      res.status(500).json({ error: 'Authorization failed' });
    }
  };
};

const managerOnly = authorize('Manager');
const employeeAccess = authorize('Manager', 'Employee');

module.exports = {
  authenticate,
  authorize,
  managerOnly,
  employeeAccess
};