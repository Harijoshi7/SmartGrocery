// routes/auth.js - Authentication Routes
const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../config/database');
const { validateLogin } = require('../middleware/validation');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
const SALT_ROUNDS = 12;

// Login
router.post('/login', validateLogin, async (req, res) => {
  try {
    const { username, password } = req.body;

    const [users] = await db.query(
      `SELECT u.UserID, u.Username, u.Password, u.RoleID, r.RoleName, u.EmployeeID
       FROM User u
       JOIN Role r ON u.RoleID = r.RoleID
       WHERE u.Username = ?`,
      [username]
    );

    if (users.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = users[0];
    const isValidPassword = await bcrypt.compare(password, user.Password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    req.session.userId = user.UserID;
    req.session.username = user.Username;
    req.session.roleId = user.RoleID;
    req.session.roleName = user.RoleName;
    req.session.employeeId = user.EmployeeID;

    await db.query(
      'UPDATE User SET LastLogin = NOW() WHERE UserID = ?',
      [user.UserID]
    );

    res.json({
      message: 'Login successful',
      user: {
        id: user.UserID,
        username: user.Username,
        role: user.RoleName,
        employeeId: user.EmployeeID
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Logout
router.post('/logout', authenticate, (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: 'Logout failed' });
    }
    res.clearCookie('connect.sid');
    res.json({ message: 'Logout successful' });
  });
});

// Get current user
router.get('/me', authenticate, async (req, res) => {
  try {
    const [users] = await db.query(
      `SELECT u.UserID, u.Username, r.RoleName, u.EmployeeID, u.LastLogin
       FROM User u
       JOIN Role r ON u.RoleID = r.RoleID
       WHERE u.UserID = ?`,
      [req.session.userId]
    );

    if (users.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user: users[0] });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Failed to fetch user' });
  }
});

// Change password
router.post('/change-password', authenticate, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Current and new passwords required' });
    }

    if (newPassword.length < 8) {
      return res.status(400).json({ error: 'New password must be at least 8 characters' });
    }

    const [users] = await db.query(
      'SELECT Password FROM User WHERE UserID = ?',
      [req.session.userId]
    );

    if (users.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const isValid = await bcrypt.compare(currentPassword, users[0].Password);
    if (!isValid) {
      return res.status(401).json({ error: 'Current password is incorrect' });
    }

    const hashedPassword = await bcrypt.hash(newPassword, SALT_ROUNDS);

    await db.query(
      'UPDATE User SET Password = ? WHERE UserID = ?',
      [hashedPassword, req.session.userId]
    );

    res.json({ message: 'Password changed successfully' });
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({ error: 'Failed to change password' });
  }
});

// Hash password utility
router.post('/hash-password', async (req, res) => {
  try {
    const { password } = req.body;
    if (!password) {
      return res.status(400).json({ error: 'Password required' });
    }
    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
    res.json({ hashedPassword });
  } catch (error) {
    console.error('Hash error:', error);
    res.status(500).json({ error: 'Failed to hash password' });
  }
});

module.exports = router;