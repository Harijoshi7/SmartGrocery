-- Database Schema for Smart Grocery Inventory System

CREATE DATABASE IF NOT EXISTS grocery_store;
USE grocery_store;

-- Role Table
CREATE TABLE Role (
    RoleID INT PRIMARY KEY AUTO_INCREMENT,
    RoleName VARCHAR(50) NOT NULL UNIQUE,
    Description TEXT
);

-- Department Table
CREATE TABLE Department (
    DepartmentID INT PRIMARY KEY AUTO_INCREMENT,
    DepartmentName VARCHAR(100) NOT NULL,
    Description TEXT
);

-- ... (rest of the schema - scroll up to see the full schema.sql artifact)