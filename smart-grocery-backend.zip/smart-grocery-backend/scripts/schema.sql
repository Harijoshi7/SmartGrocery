-- Database Schema for Smart Grocery Inventory System
-- Save this file as: schema.sql

CREATE DATABASE IF NOT EXISTS grocery_store;
USE grocery_store;

-- Drop existing tables if they exist (for clean reinstall)
DROP TABLE IF EXISTS InventoryLog;
DROP TABLE IF EXISTS Schedule;
DROP TABLE IF EXISTS TransactionDetail;
DROP TABLE IF EXISTS Transaction;
DROP TABLE IF EXISTS Inventory;
DROP TABLE IF EXISTS Product;
DROP TABLE IF EXISTS User;
DROP TABLE IF EXISTS Employee;
DROP TABLE IF EXISTS Supplier;
DROP TABLE IF EXISTS Department;
DROP TABLE IF EXISTS Role;

-- Role Table
CREATE TABLE Role (
    RoleID INT PRIMARY KEY AUTO_INCREMENT,
    RoleName VARCHAR(50) NOT NULL UNIQUE,
    Description TEXT
);

-- Department Table
CREATE TABLE Department (
    DepartmentID INT PRIMARY KEY AUTO_INCREMENT,
    DepartmentName VARCHAR(100) NOT NULL,
    Description TEXT
);

-- Employee Table
CREATE TABLE Employee (
    EmployeeID INT PRIMARY KEY AUTO_INCREMENT,
    FirstName VARCHAR(100) NOT NULL,
    LastName VARCHAR(100) NOT NULL,
    Email VARCHAR(255) UNIQUE,
    Phone VARCHAR(20),
    DepartmentID INT,
    HireDate DATE,
    FOREIGN KEY (DepartmentID) REFERENCES Department(DepartmentID)
);

-- User Table (for authentication)
CREATE TABLE User (
    UserID INT PRIMARY KEY AUTO_INCREMENT,
    Username VARCHAR(50) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    RoleID INT NOT NULL,
    EmployeeID INT,
    LastLogin DATETIME,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (RoleID) REFERENCES Role(RoleID),
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);

-- Supplier Table
CREATE TABLE Supplier (
    SupplierID INT PRIMARY KEY AUTO_INCREMENT,
    SupplierName VARCHAR(255) NOT NULL,
    ContactPerson VARCHAR(100),
    Phone VARCHAR(20),
    Email VARCHAR(255),
    Address TEXT,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Product Table
CREATE TABLE Product (
    ProductID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    Category VARCHAR(100) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL,
    SupplierID INT,
    Barcode VARCHAR(50) UNIQUE,
    ReorderLevel INT DEFAULT 10,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID),
    INDEX idx_category (Category),
    INDEX idx_barcode (Barcode)
);

-- Inventory Table
CREATE TABLE Inventory (
    InventoryID INT PRIMARY KEY AUTO_INCREMENT,
    ProductID INT NOT NULL UNIQUE,
    StockLevel INT NOT NULL DEFAULT 0,
    LastRestockDate DATETIME,
    ShelfLocation VARCHAR(50),
    UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    INDEX idx_stock_level (StockLevel)
);

-- Transaction Table
CREATE TABLE Transaction (
    TransactionID INT PRIMARY KEY AUTO_INCREMENT,
    EmployeeID INT,
    TransactionDate DATETIME NOT NULL,
    TotalAmount DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID),
    INDEX idx_transaction_date (TransactionDate)
);

-- TransactionDetail Table (Composite entity for M:N relationship)
CREATE TABLE TransactionDetail (
    TransactionDetailID INT PRIMARY KEY AUTO_INCREMENT,
    TransactionID INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (TransactionID) REFERENCES Transaction(TransactionID),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    INDEX idx_transaction (TransactionID),
    INDEX idx_product (ProductID)
);

-- Schedule Table
CREATE TABLE Schedule (
    ScheduleID INT PRIMARY KEY AUTO_INCREMENT,
    EmployeeID INT NOT NULL,
    ShiftDate DATE NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID),
    INDEX idx_shift_date (ShiftDate)
);

-- InventoryLog Table (for audit trail)
CREATE TABLE InventoryLog (
    LogID INT PRIMARY KEY AUTO_INCREMENT,
    ProductID INT NOT NULL,
    ActionType ENUM('RESTOCK', 'SALE', 'ADJUSTMENT', 'RETURN') NOT NULL,
    QuantityChange INT NOT NULL,
    NewStockLevel INT NOT NULL,
    Reason TEXT,
    PerformedBy INT,
    ActionDate DATETIME NOT NULL,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (PerformedBy) REFERENCES User(UserID),
    INDEX idx_action_date (ActionDate),
    INDEX idx_product_log (ProductID)
);

-- Insert Default Roles
INSERT INTO Role (RoleName, Description) VALUES
('Manager', 'Full access to all modules and features'),
('Employee', 'Limited access - view and update inventory only');

-- Insert Default Department
INSERT INTO Department (DepartmentName, Description) VALUES
('General', 'General store operations'),
('Sales', 'Sales and customer service'),
('Inventory', 'Stock management and ordering');

-- Insert Sample Employees
INSERT INTO Employee (FirstName, LastName, Email, Phone, DepartmentID, HireDate) VALUES
('John', 'Manager', 'john.manager@grocery.com', '555-0100', 1, '2024-01-01'),
('Jane', 'Employee', 'jane.employee@grocery.com', '555-0101', 2, '2024-02-01');

-- Insert Default Users
-- NOTE: These passwords are TEMPORARY - use 'password123' to login
-- After first login, you MUST generate proper password hashes!
INSERT INTO User (Username, Password, RoleID, EmployeeID) VALUES
('manager', 'TEMP_REPLACE_WITH_HASH', 1, 1),
('employee', 'TEMP_REPLACE_WITH_HASH', 2, 2);

-- Insert Sample Suppliers
INSERT INTO Supplier (SupplierName, ContactPerson, Phone, Email, Address) VALUES
('Fresh Produce Co.', 'Mike Smith', '555-1001', 'mike@freshproduce.com', '123 Farm Road'),
('Dairy Distributors', 'Sarah Johnson', '555-1002', 'sarah@dairydist.com', '456 Milk Lane'),
('Beverage Wholesale', 'Tom Brown', '555-1003', 'tom@bevwholesale.com', '789 Drink Street');

-- Insert Sample Products
INSERT INTO Product (Name, Category, Price, SupplierID, Barcode, ReorderLevel) VALUES
('Organic Apples', 'Produce', 2.99, 1, '1234567890', 20),
('Whole Milk', 'Dairy', 3.49, 2, '2345678901', 15),
('Orange Juice', 'Beverages', 4.99, 3, '3456789012', 10),
('Bananas', 'Produce', 0.59, 1, '4567890123', 30),
('Cheddar Cheese', 'Dairy', 5.99, 2, '5678901234', 12);

-- Insert Sample Inventory
INSERT INTO Inventory (ProductID, StockLevel, LastRestockDate, ShelfLocation) VALUES
(1, 50, NOW(), 'A-1'),
(2, 30, NOW(), 'B-2'),
(3, 25, NOW(), 'C-3'),
(4, 75, NOW(), 'A-2'),
(5, 20, NOW(), 'B-3');

-- Create Views for Common Queries
CREATE VIEW LowStockAlerts AS
SELECT 
    p.ProductID,
    p.Name,
    p.Category,
    i.StockLevel,
    p.ReorderLevel,
    s.SupplierName,
    s.Phone AS SupplierPhone
FROM Product p
JOIN Inventory i ON p.ProductID = i.ProductID
LEFT JOIN Supplier s ON p.SupplierID = s.SupplierID
WHERE i.StockLevel <= p.ReorderLevel;

-- Verify Installation
SELECT 'Database setup complete!' AS Status;
SELECT COUNT(*) AS RoleCount FROM Role;
SELECT COUNT(*) AS ProductCount FROM Product;
SELECT COUNT(*) AS SupplierCount FROM Supplier;

-- Show all tables
SHOW TABLES;