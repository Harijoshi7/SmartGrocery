const LS_TOKEN="__token__", LS_ITEMS="__items__"

if(!localStorage.getItem(LS_ITEMS)){
  const seed=[
    { id:"1", name:"Rice 5kg", sku:"R-001", quantity:25, reorder:5, category:"Grains", price:20, barcode:"111111", supplier:"Default" },
    { id:"2", name:"Beans 2kg", sku:"B-017", quantity:2,  reorder:5, category:"Grains", price:8,  barcode:"222222", supplier:"Default" },
    { id:"3", name:"Sugar 1kg", sku:"S-010", quantity:12, reorder:3, category:"Baking", price:5,  barcode:"333333", supplier:"Default" }
  ]
  localStorage.setItem(LS_ITEMS, JSON.stringify(seed))
}
const delay=ms=>new Promise(r=>setTimeout(r,ms))
const read=()=>JSON.parse(localStorage.getItem(LS_ITEMS)||"[]")
const write=v=>localStorage.setItem(LS_ITEMS, JSON.stringify(v))

export const getToken=()=>localStorage.getItem(LS_TOKEN)||""
export const setToken=t=>localStorage.setItem(LS_TOKEN,t||"")
export const clearToken=()=>localStorage.removeItem(LS_TOKEN)

export const api={
  async login(email,pwd){ await delay(150); if(!email||!pwd) throw new Error("Enter email and password"); setToken("demo-token"); return {token:"demo-token"} },
  async getItems(search=""){ await delay(120); let it=read(); if(search){ const q=search.toLowerCase(); it=it.filter(x=>(x.name||"").toLowerCase().includes(q)||(x.sku||"").toLowerCase().includes(q)||(x.barcode||"").toLowerCase().includes(q)) } return {items:it} },
  async getItem(id){ await delay(120); const it=read().find(x=>x.id===id); if(!it) throw new Error("Item not found"); return it },
  async createItem(p){ await delay(120);
    if(!p.name?.trim()) throw new Error("Name required")
    if(!p.sku?.trim()) throw new Error("SKU required")
    const items=read()
    if(items.some(x=>x.sku.toLowerCase()===p.sku.toLowerCase())) throw new Error("SKU already exists")
    const id=Date.now().toString()
    const item={ id, name:p.name, sku:p.sku, quantity:+p.quantity||0, reorder:+p.reorder||0,
      category:p.category||"", price:+p.price||0, barcode:p.barcode||"", supplier:p.supplier||"" }
    items.push(item); write(items); return {id}
  },
  async updateItem(id,p){ await delay(120);
    const items=read(); const i=items.findIndex(x=>x.id===id); if(i===-1) throw new Error("Item not found")
    if(p.sku && items.some(x=>x.id!==id && x.sku.toLowerCase()===p.sku.toLowerCase())) throw new Error("SKU exists")
    items[i]={...items[i], ...p,
      quantity:+(p.quantity ?? items[i].quantity),
      reorder:+(p.reorder ?? items[i].reorder),
      price:+(p.price ?? items[i].price)}
    write(items); return {ok:true}
  },
  async deleteItem(id){ await delay(120); const n=read().filter(x=>x.id!==id); write(n); return {ok:true} }
}
