import React,{useEffect,useState} from "react"
import { Link } from "react-router-dom"
import { api } from "../api/client.js"

export default function Dashboard(){
  const [total,setTotal]=useState(0)
  const [low,setLow]=useState(0)
  const [oos,setOos]=useState(0)

  useEffect(()=>{
    (async()=>{
      const d=await api.getItems()
      const list=d.items||[]
      setTotal(list.length)
      setLow(list.filter(it=>+it.quantity <= +it.reorder).length)
      setOos(list.filter(it=>+it.quantity === 0).length)
    })().catch(()=>{})
  },[])

  return (
    <div className="card">
      <h2 style={{marginBottom:16}}>Reports & Analytics</h2>
      <div className="kpis" style={{marginBottom:16}}>
        <div className="kpi"><div className="label">Total Products</div><div className="value">{total}</div></div>
        <div className="kpi"><div className="label">Low Stock</div><div className="value">{low}</div></div>
        <div className="kpi"><div className="label">Out of Stock</div><div className="value">{oos}</div></div>
        <div className="kpi">
          <div className="label">Reorder Threshold</div>
          <div className="value">{low} item{low===1?"":"s"} ≤ level</div>
        </div>
      </div>

      <div style={{display:"flex", gap:10}}>
        <Link to="/items" className="btn secondary">Open Products</Link>
        <Link to="/items/new" className="btn">+ New Product</Link>
      </div>
    </div>
  )
}
