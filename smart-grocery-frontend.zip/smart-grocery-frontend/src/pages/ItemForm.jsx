import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { api } from "../api/client.js";

/* ---------- numeric helpers ---------- */
const filterInt = (s) => (s ?? "").toString().replace(/[^0-9]/g, ""); // digits only
const filterDecimal = (s) =>
  (s ?? "").toString().replace(/[^0-9.]/g, "").replace(/(\..*)\./g, "$1"); // one dot
const fmt2 = (v) => (v === "" || v == null || isNaN(v) ? "0.00" : Number(v).toFixed(2));

export default function ItemForm(){
  const { id } = useParams();               // /items/:id/edit
  const nav = useNavigate();

  const [f, setF] = useState({
    name:"", sku:"", barcode:"", category:"",
    price:"", quantity:"", reorder:"", supplier:""
  });
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  useEffect(()=>{
    let mounted = true;

    async function smartLoad(){
      setLoading(true);
      setErr("");
      const wantId = (id ?? "").toString();

      const fill = (it) => {
        setF({
          name: it?.name ?? "",
          sku: it?.sku ?? "",
          barcode: it?.barcode ?? "",
          category: it?.category ?? "",
          price: fmt2(it?.price ?? 0),
          quantity: String(parseInt(it?.quantity ?? 0)),
          reorder: String(parseInt(it?.reorder ?? 0)),
          supplier: it?.supplier ?? "",
        });
      };

      try {
        // Try direct /items/:id
        let data = null;
        try { data = await api.getItem(wantId); } catch (_) {}
        let it = data?.item;

        // Fallback: list + find by id/_id/$oid
        if (!it || Object.keys(it).length === 0) {
          const all = await api.getItems("");
          const list = all?.items ?? [];
          it = list.find(x => {
            const xid = (x.id ?? x._id ?? x?._id?.$oid)?.toString();
            return xid === wantId;
          });
        }

        if (!it) {
          if (mounted) { setErr("Item not found"); setLoading(false); }
          return;
        }

        if (mounted) fill(it);
      } catch (e) {
        if (mounted) setErr(e.message || "Failed to load item");
      } finally {
        if (mounted) setLoading(false);
      }
    }

    if (!id) { setErr("Item not found"); setLoading(false); return; }
    smartLoad();
    return ()=>{ mounted = false; };
  }, [id]);

  function setField(key, val){ setF(prev => ({...prev, [key]: val})); }

  async function save(e){
    e.preventDefault();
    try{
      setErr("");
      const payload = {
        name: f.name,
        sku: f.sku,
        barcode: f.barcode,
        category: f.category,
        price: Number(f.price || 0),
        quantity: parseInt(f.quantity || 0),
        reorder: parseInt(f.reorder || 0),
        supplier: f.supplier,
      };
      await api.updateItem(id, payload);
      nav("/items");
    }catch(e){
      setErr(e.message || "Failed to save");
    }
  }

  if (loading) return <div className="card"><p>Loading…</p></div>;

  return (
    <div className="card">
      <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12}}>
        <h2>Edit Product</h2>
        <Link to="/items" className="btn secondary">← Back to Products</Link>
      </div>

      {err && <p className="error" style={{marginBottom:12}}>{err}</p>}

      <form onSubmit={save} className="grid">
        <div>
          <label>Barcode</label>
          <input value={f.barcode} onChange={(e)=>setField("barcode", e.target.value)} />
        </div>

        <div>
          <label>Product Name</label>
          <input value={f.name} onChange={(e)=>setField("name", e.target.value)} />
        </div>

        <div>
          <label>Category</label>
          <input value={f.category} onChange={(e)=>setField("category", e.target.value)} />
        </div>

        {/* Price (decimal, $ prefix, 2dp on blur) */}
        <div>
          <label>Price</label>
          <div className="input-wrap">
            <span className="input-prefix">$</span>
            <input
              className="has-prefix"
              type="text"
              inputMode="decimal"
              placeholder="0.00"
              value={f.price}
              onChange={(e)=>setField("price", filterDecimal(e.target.value))}
              onBlur={(e)=>setField("price", fmt2(e.target.value))}
              onFocus={(e)=>e.target.select()}
            />
          </div>
        </div>

        {/* Quantity (integer) */}
        <div>
          <label>Quantity</label>
          <input
            type="text"
            inputMode="numeric"
            value={f.quantity}
            onChange={(e)=>setField("quantity", filterInt(e.target.value))}
            onFocus={(e)=>e.target.select()}
          />
        </div>

        {/* Reorder (integer) */}
        <div>
          <label>Reorder Level</label>
          <input
            type="text"
            inputMode="numeric"
            value={f.reorder}
            onChange={(e)=>setField("reorder", filterInt(e.target.value))}
            onFocus={(e)=>e.target.select()}
          />
        </div>

        <div>
          <label>Supplier (optional)</label>
          <input value={f.supplier} onChange={(e)=>setField("supplier", e.target.value)} />
        </div>

        <div>
          <label>SKU</label>
          <input value={f.sku} onChange={(e)=>setField("sku", e.target.value)} />
        </div>

        <div style={{display:"flex", gap:10, alignItems:"end"}}>
          <button className="btn">Save</button>
          <Link to="/items" className="btn ghost">Cancel</Link>
        </div>
      </form>
    </div>
  );
}
