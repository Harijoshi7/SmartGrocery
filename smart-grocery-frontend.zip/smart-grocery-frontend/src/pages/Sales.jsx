// src/pages/Sales.jsx
import React, { useMemo, useState, useEffect } from "react";
import { api } from "../api/client.js";

/* ---------- helpers ---------- */
const money = (n) =>
  `$ ${Number(n || 0).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;

const filterInt = (s) =>
  (s ?? "")
    .toString()
    .replace(/[^0-9]/g, "")        // digits only
    .replace(/^0+(?=\d)/, "");     // strip leading zeroes

const LS_SALES = "smartstock_sales";
const LS_SALES_TOTAL = "smartstock_sales_total";

/* ---------- Modal ---------- */
function NewSaleModal({ open, onClose, products, onSave }) {
  const blank = { productId: products[0]?.id ?? null, qty: "" };
  const [lines, setLines] = useState([blank]);

  useEffect(() => {
    if (open) setLines([blank]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, products.length]);

  const total = useMemo(() => {
    return lines.reduce((sum, ln) => {
      const p = products.find((x) => x.id === ln.productId);
      const q = Number(ln.qty || 0);
      return sum + (p ? q * Number(p.price || 0) : 0);
    }, 0);
  }, [lines, products]);

  const setLine = (i, patch) =>
    setLines((arr) => arr.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));

  const addLine = () =>
    setLines((arr) => [...arr, { productId: products[0]?.id ?? null, qty: "" }]);

  const removeLine = (i) => setLines((arr) => arr.filter((_, idx) => idx !== i));

  const save = () => {
    const normalized = lines
      .map((l) => ({ productId: l.productId, qty: parseInt(l.qty || 0, 10) || 0 }))
      .filter((l) => l.productId && l.qty >= 1);

    if (!normalized.length) {
      alert("Add at least one product with quantity 1 or more.");
      return;
    }
    onSave(normalized, total);
    onClose();
  };

  if (!open) return null;

  return (
    <div className="modal-backdrop">
      <div className="modal-card" style={{ width: "min(760px,92vw)" }}>
        <div className="modal-head">
          <strong>New Sale</strong>
          <button className="btn secondary" onClick={onClose}>✕</button>
        </div>

        <div className="modal-body" style={{ display: "grid", gap: 16 }}>
          {lines.map((ln, idx) => (
            <div key={idx} className="card" style={{ padding: 14 }}>
              <div className="grid" style={{ gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div>
                  <label>Product</label>
                  <select
                    value={ln.productId ?? ""}
                    onChange={(e) => setLine(idx, { productId: e.target.value })}
                  >
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} — {money(p.price || 0)}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label>Quantity</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    placeholder="1"
                    value={ln.qty}
                    onChange={(e) => setLine(idx, { qty: filterInt(e.target.value) })}
                    onFocus={(e) => e.target.select()}
                  />
                </div>
              </div>

              <div style={{ marginTop: 10 }}>
                <button className="btn secondary" onClick={() => removeLine(idx)}>
                  Remove
                </button>
              </div>
            </div>
          ))}

          <div>
            <button className="btn secondary" onClick={addLine}>+ Add another product</button>
          </div>

          <div className="grid" style={{ gridTemplateColumns: "1fr", gap: 12 }}>
            <div className="card" style={{ padding: 18 }}>
              <div className="muted" style={{ fontSize: ".9rem" }}>Total</div>
              <div style={{ fontWeight: 800, fontSize: "1.6rem" }}>{money(total)}</div>
            </div>
          </div>

          <div>
            <button className="btn" onClick={save}>Save Sale</button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */
export default function Sales() {
  const [items, setItems] = useState([]);

  // ✅ Hydrate sales from localStorage synchronously on first render
  const [sales, setSales] = useState(() => {
    try {
      const raw = localStorage.getItem(LS_SALES);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  // load products
  useEffect(() => {
    (async () => {
      const d = await api.getItems("");
      setItems(d.items || []);
    })();
  }, []);

  // persist sales + expose grand total for Reports
  useEffect(() => {
    try {
      localStorage.setItem(LS_SALES, JSON.stringify(sales));
      const grand = sales.reduce((s, r) => s + Number(r.total || 0), 0);
      localStorage.setItem(LS_SALES_TOTAL, String(grand));
    } catch {
      // ignore storage errors
    }
  }, [sales]);

  const addSale = (lines, total) => {
    const details = lines
      .map((ln) => {
        const p = items.find((x) => x.id === ln.productId);
        return p ? `${p.name} ×${ln.qty}` : `Unknown ×${ln.qty}`;
      })
      .join(", ");

    setSales((arr) => [
      {
        id: (crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`),
        at: new Date().toISOString(),
        lines,
        total,
        details,
      },
      ...arr,
    ]);
  };

  const removeSale = (id) => setSales((arr) => arr.filter((r) => r.id !== id));

  return (
    <div className="card">
      <div className="tb-row">
        <h2>Sales</h2>
        <div className="tb-actions">
          <button className="btn" onClick={() => (document.getElementById("open-sale")?.click())}>
            + New Sale
          </button>
          {/* hidden anchor to open modal via state */}
        </div>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <table style={{ width: "100%", borderCollapse: "separate", borderSpacing: "0 6px" }}>
          <thead>
            <tr>
              <th style={{ textAlign: "left", padding: "12px 14px" }}>Date</th>
              <th style={{ textAlign: "left", padding: "12px 14px" }}>Details</th>
              <th style={{ textAlign: "left", padding: "12px 14px" }}>Items</th>
              <th style={{ textAlign: "left", padding: "12px 14px" }}>Total</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {sales.length === 0 && (
              <tr>
                <td style={{ padding: "14px" }} colSpan={5}>
                  Running in local-only mode (no sales API detected). Data is stored in your browser and will not sync to the server.
                </td>
              </tr>
            )}
            {sales.map((s) => {
              const d = s.at ? new Date(s.at) : null;
              const dateStr = d && !isNaN(d) ? d.toLocaleString() : "Invalid Date";
              const count = (s.lines || []).reduce((n, ln) => n + Number(ln.qty || 0), 0);
              return (
                <tr key={s.id} style={{ background: "var(--card)" }}>
                  <td style={{ padding: "12px 14px" }}>{dateStr}</td>
                  <td style={{ padding: "12px 14px" }}>{s.details || "—"}</td>
                  <td style={{ padding: "12px 14px" }}>{count}</td>
                  <td style={{ padding: "12px 14px" }}>{money(s.total)}</td>
                  <td style={{ padding: "12px 14px" }}>
                    <button className="btn secondary" onClick={() => removeSale(s.id)}>
                      Remove
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Modal (controlled here) */}
      <NewSaleModal
        open={true && false /* placeholder – we open via a state variable below */}
        onClose={() => {}}
        products={items}
        onSave={addSale}
      />
      {/* Simple state toggle for modal */}
      <ModalGate products={items} onSave={addSale} />
    </div>
  );
}

/* A tiny gate to control the modal with simple state (keeps parent tidy) */
function ModalGate({ products, onSave }) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const btn = document.createElement("button");
    btn.id = "open-sale";
    btn.style.display = "none";
    btn.onclick = () => setOpen(true);
    document.body.appendChild(btn);
    return () => document.body.removeChild(btn);
  }, []);
  return (
    <NewSaleModal
      open={open}
      onClose={() => setOpen(false)}
      products={products}
      onSave={onSave}
    />
  );
}
