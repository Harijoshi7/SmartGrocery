// src/pages/Suppliers.jsx
import React, { useEffect, useState } from "react";
import { api } from "../api/client.js";

export default function Suppliers() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        setErr("");
        const res = await api.getItems("");
        setItems(res.items || []);
      } catch (e) {
        setErr(e.message || "Failed to load items.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // Group products by supplier name, filter out blanks
  const suppliers = Object.values(
    (items || [])
      .filter((x) => x.supplier && x.supplier.trim() !== "")
      .reduce((acc, it) => {
        const key = it.supplier.trim();
        if (!acc[key]) {
          acc[key] = { name: key, contact: "—", email: "—", phone: "—", products: 0 };
        }
        acc[key].products += 1;
        return acc;
      }, {})
  );

  return (
    <div className="card">
      <h2>Suppliers</h2>

      {loading && <p>Loading…</p>}
      {err && <p className="error">{err}</p>}

      {!loading && (
        <>
          <table style={{ width: "100%", marginTop: 10 }}>
            <thead>
              <tr>
                <th style={{ textAlign: "left" }}>Name</th>
                <th style={{ textAlign: "left" }}>Contact</th>
                <th style={{ textAlign: "left" }}>Email</th>
                <th style={{ textAlign: "left" }}>Phone</th>
                <th style={{ textAlign: "left" }}>Products</th>
              </tr>
            </thead>
            <tbody>
              {suppliers.length ? (
                suppliers.map((s) => (
                  <tr key={s.name}>
                    <td>{s.name}</td>
                    <td>{s.contact}</td>
                    <td>{s.email}</td>
                    <td>{s.phone}</td>
                    <td>{s.products}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5" style={{ textAlign: "center", color: "var(--muted)" }}>
                    No suppliers found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>

          <p style={{ marginTop: 10, color: "var(--muted)" }}>
            This list is derived from product data (<code>item.supplier</code>).
            Add/edit suppliers will appear once a suppliers API is available.
          </p>
        </>
      )}
    </div>
  );
}
